// Exercise 1 
x = 10;
y = 5;
alert(x > y);

// Exercise 2
x = 10;
y = 5;
alert(x == y);

// Exercise 3
x = 10;
y = 5;
alert(x != y);

// Exercise 4
var age = n;
var voteable = (age < 18) ? "Too young" : "Old enough" ;
alert(voteable);