var length = 16;          // number

var lastName = "Johnson"; // string 

var x = {
  firstName: "John",
  lastName: "Doe"
};                        // object