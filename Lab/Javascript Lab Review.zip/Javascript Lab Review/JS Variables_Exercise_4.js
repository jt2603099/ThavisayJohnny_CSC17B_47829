var x = 5;
var y = 10;
var z = x + y;
alert(z);