var firstName = "John", var lastName = "Doe", age = 35;

