//Exercise 1
function myFunction() {
  alert("Hello World!");
}
myFunction();

//Exercise 2
function myFunction() {
	alert(Hello World!");
}

//Exercise 3
function myFunction() {
	return "Hello";
}
document.getElementById("demo").innerHTML = myFunction();

//Exercise 4
function myFunction() {
	document.getElementById("demo").innerHTML = "Hello";
}