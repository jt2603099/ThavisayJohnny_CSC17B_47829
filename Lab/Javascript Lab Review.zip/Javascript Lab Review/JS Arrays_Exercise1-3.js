// Exercise 1
var cars = ["Saab", "Volvo", "BMW"];
var x = cars[1];

// Exercise 2
var cars = ["Volvo", "Jeep", "Mercedes"];
cars[0] = "Ford";

// Exercise 3
var cars = ["Volvo", "Jeep", "Mercedes"];
alert(cars.length);