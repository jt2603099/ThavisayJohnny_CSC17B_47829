var fruits = ["Banana", "Orange", "Apple", "Kiwi"];
fruits.sort();