// Exercise 1
for (i = 0; i < 10; i++) {
	console.log(i);
	if (i == 5) {
		break;
	}
}

// Exercise 2
for (i = 0; i < 10; i++) {
	if (i == 5) {
		continue;
	}
	console.log(i);
}