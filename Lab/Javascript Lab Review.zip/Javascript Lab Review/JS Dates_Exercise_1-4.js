// Exercise 1
var d = new Date();
alert(d);

// Exercise 2
var d = new Date();
year = d.getFullYear();

// Exercise 3
var d = new Date();
month = d.getMonth();

// Exercise 4
var d = new Date();
d.setFullYear(2020);