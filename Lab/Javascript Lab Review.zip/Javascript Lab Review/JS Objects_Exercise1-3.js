//Exercise 1
var person = {
  firstName: "John",
  lastName: "Doe"
};

alert(person.firstName);

//Exercise 2
var person = {
  firstName: "John",
  lastName: "Doe",
  country: "Norway"
};

//Exercise 3
 var person = {
  name:"John", age:50
};
alert(person.name+ " is " + person.age);