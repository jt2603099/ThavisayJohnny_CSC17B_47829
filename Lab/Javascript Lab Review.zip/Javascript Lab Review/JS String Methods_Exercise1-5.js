// Exercise 1
var txt = "abcdefghijklm";
var pos = txt.indexOf("h");

// Exercise 2
var txt = "I can eat bananas all day";
var x = txt.slice(10,17);

// Exercise 3
var txt = "Hello World";
txt = txt.
replace
("Hello", "Welcome");

// Exercise 4
var txt = "Hello World";
txt = 
txt.toUpperCase();

// Exercise 5
var txt = "Hello World";
txt = txt.toLowerCase();