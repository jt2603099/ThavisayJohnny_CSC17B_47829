// Exercise 1
var i;
for (i = 0; i < 10; i++) {
	console.log(i);
}

// Exercise 2
var fruits = ["Apple", "Banana", "Orange"];
for (x of fruits) {
	console.log(x);
}