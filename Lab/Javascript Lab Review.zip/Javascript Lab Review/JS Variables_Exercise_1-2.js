var carName = "Volvo";
var x = 50;