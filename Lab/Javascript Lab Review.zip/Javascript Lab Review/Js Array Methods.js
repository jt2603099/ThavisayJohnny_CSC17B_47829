// Exercise 1
var fruits = ["Banana", "Orange", "Apple"];
fruits.pop();

// Exercise 2
var fruits = ["Banana", "Orange", "Apple"];
fruits.push("Kiwi");

//Eercise 3 
var fruits = ["Banana", "Orange", "Apple", "Kiwi"];
fruits.splice(1, 2);