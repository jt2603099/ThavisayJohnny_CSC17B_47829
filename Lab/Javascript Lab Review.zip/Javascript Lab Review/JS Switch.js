// Exercise 1
switch(fruits) {
	case "Banana":
		alert("Hello")
		break;
	case "Apple":
		alert("Welcome")
		break;
}

// Exercise 2
switch(fruits) {
	case "Banana":
		alert("Hello")
		break;
	case "Apple":
		alert("Welcome")
		break;
	default:
		alert("Neither");
}