// Exercise 1
var txt = "Hello World!";
var x = txt.length;
alert(x);

// Exercise 2
var txt = "We are \"Vikings\"";
alert(txt);

// Exercise 3
var str1 = "Hello ";
var str2 = "World! ";
alert(str1 + str2);

// Exercise 4
var txt = "abcdefghijklm";
var pos = txt.indexOf('h');