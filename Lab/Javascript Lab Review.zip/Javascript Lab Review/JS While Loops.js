// Exercise 1
var i = 0;
while (i < 10) {
	console.log(i);
	i++
}

// Exercise 2
var i = 0;
while (i < 10) {
  console.log(i);
  i = i + 2;
}