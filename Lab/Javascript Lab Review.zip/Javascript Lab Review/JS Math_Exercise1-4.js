// Exercise 1
var r = Math.random();

// Exercise 2
var x = Math.max(10,20);

// Exercise 3
var x = Math.round(5.3);

// Exercise 4
var x = Math.sqrt(9);