// Exercise 1
<button onclick="alert('Hello')">Click me.</button>

// Exercise 2
<button 
onclick="myFunction()">Click me.</button>

// Exercise 3
<div onmouseover="this.style.backgroundColor='red'">myDIV.</div>