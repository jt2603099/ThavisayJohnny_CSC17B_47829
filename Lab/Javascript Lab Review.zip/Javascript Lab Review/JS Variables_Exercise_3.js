var x = 5;
var y = 10;
document.getElementById("demo").innerHTML = x + y;