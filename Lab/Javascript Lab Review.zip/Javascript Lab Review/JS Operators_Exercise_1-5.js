alert(10 * 5); //Ex 1

alert(10 / 2); //Ex 2

alert(15 % 9); //Ex 3

//Ex 4
x = 10;
y = 5;
x += y;

//Ex 5
x = 10;
y = 5;
x *= y;
