// Exercise 1
if (x > y) {
	alert("Hello World");
}

// Exercise 2
if (x > y) {
	alert("Hello World");
} else {
	alert ("Goodbye");
}